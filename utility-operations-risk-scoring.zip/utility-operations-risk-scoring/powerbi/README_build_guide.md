# Power BI build guide - Utility Operations Command Centre

> **Why there is no `.pbix` in this folder:** a `.pbix` is a binary file that can only be saved from
> Power BI Desktop (Windows). Everything needed to build it in about **45-60 minutes** is here:
> the data-load script, every DAX measure, a colour theme, a visual-by-visual layout and the numbers
> your finished dashboard must show. When you are done, save your file as
> `powerbi/Utility_Operations_Command_Centre.pbix` and add screenshots to `powerbi/screenshots/`.

| File | What it is |
|---|---|
| `01_power_query_load.m` | Power Query (M) script - loads the single flat table `Fact_Utility_Interactions` |
| `02_dax_measures.dax` | All DAX: outlier toggle, KPIs, smart narrative, alert colour, what-if simulation |
| `theme_utility_ops.json` | Colour theme (View > Themes > Browse for themes) |
| `expected_values_by_region.csv` / `expected_values_network.json` | Independent Python results - use them to check your dashboard |

---

## 1. Load the data (5 min)

1. Run the Python pipeline first (`python python/run_pipeline.py`) so that
   `data/processed/utility_operations_clean.csv` exists.
2. Power BI Desktop -> **Home -> Get data -> Blank query -> Advanced Editor**.
3. Paste all of `01_power_query_load.m`, change the `FilePath` line to your real path, click **Done**.
4. Rename the query to **`Fact_Utility_Interactions`** -> **Close & Apply**.

> No star schema, no `Dim_Date`: the brief asks for one flat fact table. Time analysis uses the
> built-in date hierarchy on `request_date` (or the ready-made `request_month` column).

## 2. Tidy the model (5 min)

In **Data view** select the table, then:

| Column | Setting |
|---|---|
| `priority` | **Column tools -> Sort by column -> `priority_sort`** (so the legend reads Emergency, High, Medium, Low) |
| `request_month` | Format `mmm yyyy` |
| `sla_breach_flag`, `*_flag`, `priority_sort`, `record_id`, `source_row_number` | **Hide in report view** (helper columns) |
| `Customer_Friction_Score` | Summarisation = **Average** |
| `billing_amount_gbp` | Format Currency (GBP) |

## 3. Create the tables and measures (10 min)

Open `02_dax_measures.dax` and paste each block as a **New table** / **New measure**:

1. **Outlier Toggle** table (section A1) -> set `Mode` to *Sort by column* `Sort`.
2. **What-if parameter**: **Modeling -> New parameter -> Numeric range**
   `Name: Engineer Capacity Increase`, Min `0.05`, Max `0.25`, Increment `0.01`, Default `0.10`,
   tick *Add slicer*. Format the column as **Percentage**.
3. All measures in sections B to G. (Skip `Engineer Capacity Increase Value` if Power BI already
   generated a measure with that name.)

## 4. Apply the theme (1 min)

**View -> Themes -> Browse for themes -> `theme_utility_ops.json`.**

## 5. Build the page (20-30 min)

Set the page size to **16:9 (1280 x 720)** and rename the page **Command Centre**.

```
+----------------------------------------------------------------------------------+
|  TITLE: Utility Customer Operations - Command Centre          [Outlier toggle]   |
+------------+------------+------------+------------+------------------------------+
| Utility    | Region     | Priority   | Meter type |  Smart narrative (text card) |
| slicer     | slicer     | slicer     | slicer     |                              |
+------------+------------+------------+------------+------------------------------+
| KPI 1      | KPI 2      | KPI 3      | KPI 4      | KPI 5 (what-if hours saved)  |
| Interactions| Avg res hrs| SLA compl.%| Friction * | + capacity slider            |
+------------+------------+------------+------------+------------------------------+
|  LINE: avg resolution hours + SLA %   |  MATRIX HEATMAP: region x complaint cat. |
|  by request month                     |                                          |
+---------------------------------------+------------------------------------------+
```

### Visual-by-visual specification

| # | Visual | Fields | Notes |
|---|---|---|---|
| 1 | **Slicer** (Dropdown) | `utility_type` | Format -> Slicer settings -> Style = Dropdown |
| 2 | **Slicer** (Dropdown) | `region` | Multi-select on |
| 3 | **Slicer** (Tile / Dropdown) | `priority` | This is the **recalculated** tier |
| 4 | **Slicer** (Dropdown) | `meter_type` | |
| 5 | **Slicer** (Tile) | `Outlier Toggle[Mode]` | Single select. Default = *Exclude suspect outliers* |
| 6 | **Card** | `[Total Interactions]` | |
| 7 | **Card** | `[Avg Resolution Hours]` | Units: hours, 1 decimal |
| 8 | **Card** | `[SLA Compliance %]` | Format 0.0% |
| 9 | **Card** (alert KPI) | `[Avg Friction Score]` | Conditional colour - see section 7 |
| 10 | **Card** | `[Projected Resolution Hours Saved]` | Next to the what-if slider |
| 11 | **What-if slider** | `Engineer Capacity Increase` | Created in step 3 |
| 12 | **Line chart** | X = `request_month` (or `request_date` -> Month). Y = `[Avg Resolution Hours]`. Secondary Y = `[SLA Compliance %]` | If your Power BI has no *Secondary y-axis* well on the line chart, use **Line and clustered column chart** and put both measures in *Line y-axis* |
| 13 | **Matrix** | Rows = `region`; Columns = `complaint_category`; Values = `[Complaints]` | Filter pane: `complaint_category` **is not** "Not Recorded". Cell elements -> Background colour -> *Gradient* (white to red) = the **heatmap** |
| 14 | **Card** (text) | `[Region SLA Narrative]` | Wide card, 11-12 pt font, word-wrap on |

Turn on **Edit interactions** where needed so the what-if slider does not filter the line chart.

## 6. Smart narrative (the "Text Generation Measure")

`[Region SLA Narrative]` uses DAX variables to build a sentence from live numbers:

* **Pick one region** in the slicer -> *"Watch closely. Wales is breaching SLA on 20.5% of resolved
  tickets (...), above the network average of 19.8%. The most frequent friction indicator is
  'Overcharged' with 225 complaints."*
* **No selection** -> the same sentence for "The network".

## 7. Multi-condition KPI alert (Red only if BOTH conditions are true)

Select visual 9 -> **Format -> Callout value -> Font colour -> fx**:

* Format style = **Field value**, based on `[KPI Alert Colour]`.

The measure returns red (`#E63946`) only when **both** are true:

1. the region's average `Customer_Friction_Score` is **lower than the network average**, **and**
2. the share of **High + Emergency** tickets is **higher than the network share**.

Otherwise it returns green. Add a second card with `[KPI Alert Label]` for an accessible text version.
To test it, put a **Table** visual with `region`, `[Avg Friction Score]`, `[High + Emergency Share]`,
`[KPI Is Critical]` on a scratch page - it should flag Scotland, South West, Wales and West Midlands.

## 8. What-if simulation

Drag the **Engineer Capacity Increase** slider between 5% and 25%:

* `[Projected Resolution Hours Saved]` = total resolution hours x slider %
* `[Projected Avg Resolution Hours]` = current average x (1 - slider %)
* `[Projected SLA Compliance %]` = SLA compliance if every ticket were that much faster (bonus)

## 9. Check your numbers (important)

With **no slicer selected** and the toggle on **Exclude suspect outliers**, your page should show
(from `expected_values_network.json`):

| Measure | Expected |
|---|---|
| Total Interactions | **94,796** |
| Avg Resolution Hours | **30.45** |
| SLA Compliance % | **80.18%** |
| Avg Friction Score (network) | **89.02** |
| Projected Resolution Hours Saved @ 10% | **242,698** |
| Projected Resolution Hours Saved @ 25% | **606,746** |
| Projected SLA Compliance @ 10% | **82.07%** |

Switch the toggle to **Include all records** and Avg Resolution Hours jumps to **124.55** - that jump
*is* the data-quality finding (1.5% of tickets hold 76% of all logged hours).
Per-region values are in `expected_values_by_region.csv`.

## 10. Optional page 2 - "Data Quality"

* Card `[Suspect Outlier Tickets]` (1,417) and `[Legacy Label Matches Recalculated %]` (34.2%).
* Clustered column: `priority_raw` vs average `resolution_time_hours` -> flat bars prove the legacy label has no signal.
* Table of `Region_Resolution_Volatility_Index` vs `Region_Resolution_Volatility_Index_Clean` by region.

## 11. Export for the portfolio

1. **File -> Save as** `Utility_Operations_Command_Centre.pbix` into this folder.
2. **File -> Export -> Export to PDF** -> `powerbi/screenshots/dashboard.pdf`.
3. Screenshots (Win + Shift + S) of: default view, one region selected (narrative + alert),
   slider at 5% and at 25%, outlier toggle on/off -> `powerbi/screenshots/`.
4. Optional: record a 20-second screen capture (Xbox Game Bar: Win + G) and convert it to a GIF.
