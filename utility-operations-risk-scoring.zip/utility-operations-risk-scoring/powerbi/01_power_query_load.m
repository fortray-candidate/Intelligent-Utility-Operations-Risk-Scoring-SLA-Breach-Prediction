// =====================================================================================
// POWER QUERY (M) - loads the single flat fact table  Fact_Utility_Interactions
//
// HOW TO USE
//   Power BI Desktop > Home > Get data > Blank query > Advanced Editor >
//   delete everything > paste this whole file > change FilePath > Done.
//   Then rename the query to  Fact_Utility_Interactions  and click Close & Apply.
//
// (Prefer loading from MySQL instead of the CSV? See OPTION B at the bottom.)
// =====================================================================================
let
    // ---- 1. EDIT THIS LINE: full path to the CSV produced by the Python pipeline ----
    FilePath = "C:\Users\YOU\Documents\utility-operations-risk-scoring\data\processed\utility_operations_clean.csv",

    // ---- 2. read the file ------------------------------------------------------------
    Source   = Csv.Document(File.Contents(FilePath), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),

    // ---- 3. set every data type explicitly (en-US culture = '.' decimal point) -------
    Typed = Table.TransformColumnTypes(Promoted, {
        {"record_id", Int64.Type}, {"source_row_number", Int64.Type},
        {"interaction_id", type text}, {"customer_id", type text}, {"account_number", type text},
        {"utility_type", type text}, {"region", type text}, {"postcode", type text},
        {"customer_segment", type text}, {"meter_type", type text}, {"service_type", type text},
        {"priority_raw", type text},
        {"request_date", type date}, {"resolution_date", type date}, {"request_month", type date},
        {"sla_target_hours", Int64.Type}, {"resolution_time_hours", type number},
        {"engineer_visit_required", type text}, {"engineer_id", type text},
        {"meter_reading_previous", type number}, {"meter_reading_current", type number},
        {"consumption_units", type number}, {"billing_amount_gbp", type number},
        {"payment_method", type text}, {"complaint_flag", type text}, {"complaint_category", type text},
        {"customer_satisfaction_score", Int64.Type}, {"channel", type text},
        {"outage_related", type text}, {"outage_duration_minutes", type number},
        {"created_by_agent_id", type text},
        {"sla_imputed_flag", Int64.Type}, {"billing_sign_corrected_flag", Int64.Type},
        {"resolution_outlier_flag", Int64.Type}, {"consumption_outlier_flag", Int64.Type},
        {"complaint_conflict_flag", Int64.Type}, {"duplicate_interaction_id_flag", Int64.Type},
        {"priority", type text}, {"priority_basis", type text}, {"priority_changed_flag", Int64.Type},
        {"Customer_Friction_Score", Int64.Type},
        {"Region_Resolution_Volatility_Index", type number},
        {"Region_Resolution_Volatility_Index_Clean", type number},
        {"sla_breach_flag", Int64.Type}
    }, "en-US"),

    // ---- 4. text version of the SLA flag (avoids DAX's "blank = 0" trap) -------------
    AddSlaStatus = Table.AddColumn(Typed, "sla_status",
        each if [sla_breach_flag] = null then "Unknown"
             else if [sla_breach_flag] = 1 then "Breached"
             else "Met", type text),

    // ---- 5. sort helper so priority always shows Emergency > High > Medium > Low -----
    AddPrioritySort = Table.AddColumn(AddSlaStatus, "priority_sort",
        each if [priority] = "Emergency" then 1
             else if [priority] = "High" then 2
             else if [priority] = "Medium" then 3
             else 4, Int64.Type),

    // ---- 6. friendly label for the outlier flag (used in slicers / tooltips) ---------
    AddOutlierLabel = Table.AddColumn(AddPrioritySort, "resolution_record_quality",
        each if [resolution_outlier_flag] = 1 then "Suspect outlier (>1,000h)" else "Normal", type text)
in
    AddOutlierLabel


// =====================================================================================
// OPTION B - load straight from MySQL (the table created by step5_load_db.py)
// Replace the whole query above with:
//
// let
//     Source = MySQL.Database("localhost", "portfolio"),
//     Table  = Source{[Schema = "portfolio", Item = "utility_customer_operations"]}[Data],
//     AddSlaStatus = Table.AddColumn(Table, "sla_status",
//         each if [sla_breach_flag] = null then "Unknown" else if [sla_breach_flag] = 1 then "Breached" else "Met", type text),
//     AddPrioritySort = Table.AddColumn(AddSlaStatus, "priority_sort",
//         each if [priority] = "Emergency" then 1 else if [priority] = "High" then 2 else if [priority] = "Medium" then 3 else 4, Int64.Type),
//     AddOutlierLabel = Table.AddColumn(AddPrioritySort, "resolution_record_quality",
//         each if [resolution_outlier_flag] = 1 then "Suspect outlier (>1,000h)" else "Normal", type text)
// in
//     AddOutlierLabel
//
// (MySQL needs the "MySQL Connector/NET" driver installed once on your PC.)
// =====================================================================================
