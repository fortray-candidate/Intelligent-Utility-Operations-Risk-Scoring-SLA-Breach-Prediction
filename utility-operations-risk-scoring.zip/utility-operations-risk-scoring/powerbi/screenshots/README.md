# Screenshots go here

After building the dashboard (see `../README_build_guide.md`), add:

- `dashboard_default.png` - Command Centre, no slicers selected
- `dashboard_region_selected.png` - one region selected (smart narrative + red/green alert)
- `whatif_5pct.png` and `whatif_25pct.png` - slider at both ends
- `outlier_toggle_comparison.png` - toggle on vs off
- `dashboard.pdf` - File > Export > PDF

The charts in `../../docs/figures/` are **Python (matplotlib)** companion charts, not Power BI exports.
