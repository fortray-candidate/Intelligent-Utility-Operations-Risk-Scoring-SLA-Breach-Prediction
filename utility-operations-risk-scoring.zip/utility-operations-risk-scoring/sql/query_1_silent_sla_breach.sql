-- =====================================================================================
-- QUERY 1 : The "Silent SLA Breach" Detector
-- Table   : utility_customer_operations
-- Technique: multi-condition HAVING clause with nested SUM(CASE ...) statements
--            (no CTEs, no window functions)
--
-- Business question
--   Which region + utility_type combinations
--     (a) take on average MORE THAN 150% of their SLA target to resolve, AND
--     (b) log a friction event (a complaint OR an outage-related ticket) in more
--         than 25% of their interactions?
--
-- Notes
--   * The SLA average is taken over the same tickets that have a resolution time,
--     so we compare like with like (open tickets are excluded from both sides).
--   * Works on MySQL 5.7+/8.0, MariaDB, PostgreSQL, SQL Server and SQLite.
-- =====================================================================================
SELECT
    region,
    utility_type,
    COUNT(*)                                                         AS interactions,
    ROUND(AVG(resolution_time_hours), 1)                             AS avg_resolution_hours,
    ROUND(AVG(CASE WHEN resolution_time_hours IS NOT NULL
                   THEN sla_target_hours END), 1)                    AS avg_sla_target_hours,
    ROUND(100.0 * AVG(resolution_time_hours)
          / AVG(CASE WHEN resolution_time_hours IS NOT NULL
                     THEN sla_target_hours END), 1)                  AS resolution_as_pct_of_sla,
    ROUND(100.0 * SUM(CASE WHEN complaint_flag = 'Yes'
                             OR outage_related = 'Yes' THEN 1 ELSE 0 END)
          / COUNT(*), 1)                                             AS friction_rate_pct
FROM utility_customer_operations
GROUP BY region, utility_type
HAVING AVG(resolution_time_hours) >
           1.5 * AVG(CASE WHEN resolution_time_hours IS NOT NULL
                          THEN sla_target_hours END)
   AND SUM(CASE WHEN complaint_flag = 'Yes'
                  OR outage_related = 'Yes' THEN 1 ELSE 0 END) > 0.25 * COUNT(*)
ORDER BY resolution_as_pct_of_sla DESC;


-- -------------------------------------------------------------------------------------
-- SENSITIVITY CHECK (same query, but ignoring the ~1.5% of tickets flagged as suspect
-- outliers - resolution times of 2,000-9,000 hours that contradict the ticket dates).
-- If the list above collapses to nothing here, the "silent breach" is a data-quality
-- artefact rather than an operational problem.
-- -------------------------------------------------------------------------------------
SELECT
    region,
    utility_type,
    COUNT(*)                                                         AS interactions,
    ROUND(AVG(resolution_time_hours), 1)                             AS avg_resolution_hours,
    ROUND(AVG(CASE WHEN resolution_time_hours IS NOT NULL
                   THEN sla_target_hours END), 1)                    AS avg_sla_target_hours,
    ROUND(100.0 * AVG(resolution_time_hours)
          / AVG(CASE WHEN resolution_time_hours IS NOT NULL
                     THEN sla_target_hours END), 1)                  AS resolution_as_pct_of_sla,
    ROUND(100.0 * SUM(CASE WHEN complaint_flag = 'Yes'
                             OR outage_related = 'Yes' THEN 1 ELSE 0 END)
          / COUNT(*), 1)                                             AS friction_rate_pct
FROM utility_customer_operations
WHERE resolution_outlier_flag = 0
GROUP BY region, utility_type
HAVING AVG(resolution_time_hours) >
           1.5 * AVG(CASE WHEN resolution_time_hours IS NOT NULL
                          THEN sla_target_hours END)
   AND SUM(CASE WHEN complaint_flag = 'Yes'
                  OR outage_related = 'Yes' THEN 1 ELSE 0 END) > 0.25 * COUNT(*)
ORDER BY resolution_as_pct_of_sla DESC;
