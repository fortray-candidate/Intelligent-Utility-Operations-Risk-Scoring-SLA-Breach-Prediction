-- =====================================================================================
-- QUERY 4 : The "False Priority Alarm" Audit
-- Table   : utility_customer_operations
-- Technique: set comparison mixing COUNT() with conditional SUM()
--
-- Business question
--   Which regions raise false Emergency alarms? For every region, of the interactions
--   labelled 'Emergency' by the call centre, what % were actually resolved INSIDE their
--   SLA target (resolution_time_hours <= sla_target_hours)? Return regions above 20%.
--
-- Which label? 'priority_raw' is the legacy call-centre label - the thing being
--   audited. (The recalculated 'priority' column is a rule built from outage minutes
--   and resolution time, so it is not an "alarm" a person raised. See Variant B.)
--
-- Only tickets with BOTH a resolution time and an SLA target can be judged, so the
--   denominator is "Emergency-labelled tickets that can be judged".
-- =====================================================================================
SELECT
    region,
    COUNT(*)                                                              AS emergency_labelled_tickets,
    SUM(CASE WHEN resolution_time_hours <= sla_target_hours THEN 1 ELSE 0 END) AS resolved_inside_sla,
    ROUND(100.0 * SUM(CASE WHEN resolution_time_hours <= sla_target_hours
                           THEN 1 ELSE 0 END) / COUNT(*), 2)              AS false_alarm_pct
FROM utility_customer_operations
WHERE priority_raw = 'Emergency'
  AND resolution_time_hours IS NOT NULL
  AND sla_target_hours IS NOT NULL
GROUP BY region
HAVING 100.0 * SUM(CASE WHEN resolution_time_hours <= sla_target_hours
                        THEN 1 ELSE 0 END) / COUNT(*) > 20
ORDER BY false_alarm_pct DESC;


-- -------------------------------------------------------------------------------------
-- VARIANT A (context): the same audit for EVERY region (no threshold), plus how many
-- of the region's judged tickets carried the Emergency label at all.
-- -------------------------------------------------------------------------------------
SELECT
    region,
    COUNT(*)                                                              AS judged_tickets,
    SUM(CASE WHEN priority_raw = 'Emergency' THEN 1 ELSE 0 END)           AS emergency_labelled,
    SUM(CASE WHEN priority_raw = 'Emergency'
              AND resolution_time_hours <= sla_target_hours THEN 1 ELSE 0 END) AS emergency_inside_sla,
    ROUND(100.0 * SUM(CASE WHEN priority_raw = 'Emergency'
                            AND resolution_time_hours <= sla_target_hours THEN 1 ELSE 0 END)
          / SUM(CASE WHEN priority_raw = 'Emergency' THEN 1 ELSE 0 END), 2) AS false_alarm_pct
FROM utility_customer_operations
WHERE resolution_time_hours IS NOT NULL
  AND sla_target_hours IS NOT NULL
GROUP BY region
ORDER BY false_alarm_pct DESC;


-- -------------------------------------------------------------------------------------
-- VARIANT B: audit the RECALCULATED priority instead (outage >= 180 min). Because those
-- outage tickets are mostly closed well inside their SLA, almost every region clears
-- the 20% bar - the threshold stops discriminating, which is why Variant B is not the
-- headline query.
-- -------------------------------------------------------------------------------------
SELECT
    region,
    COUNT(*)                                                              AS emergency_recalculated,
    SUM(CASE WHEN resolution_time_hours <= sla_target_hours THEN 1 ELSE 0 END) AS resolved_inside_sla,
    ROUND(100.0 * SUM(CASE WHEN resolution_time_hours <= sla_target_hours
                           THEN 1 ELSE 0 END) / COUNT(*), 2)              AS false_alarm_pct
FROM utility_customer_operations
WHERE priority = 'Emergency'
  AND resolution_time_hours IS NOT NULL
  AND sla_target_hours IS NOT NULL
GROUP BY region
HAVING 100.0 * SUM(CASE WHEN resolution_time_hours <= sla_target_hours
                        THEN 1 ELSE 0 END) / COUNT(*) > 20
ORDER BY false_alarm_pct DESC;
