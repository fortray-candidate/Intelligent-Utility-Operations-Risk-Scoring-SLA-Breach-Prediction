-- =====================================================================================
-- QUERY 3 : Meter Type Engagement Stress Test
-- Table   : utility_customer_operations
-- Technique: cross-conditional aggregation ("pivoting") in SELECT and HAVING
--
-- Business question
--   For each meter type, how much longer does a ticket take when a field engineer
--   visit is required? Return only meter types where the visit adds MORE THAN 40 hours.
-- =====================================================================================
SELECT
    meter_type,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END), 1) AS avg_hours_with_visit,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END), 1) AS avg_hours_without_visit,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END)
        - AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END), 1) AS visit_uplift_hours
FROM utility_customer_operations
GROUP BY meter_type
HAVING AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END)
     - AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END) > 40
ORDER BY visit_uplift_hours DESC;


-- -------------------------------------------------------------------------------------
-- DIAGNOSTIC VERSION (no threshold) - shows the uplift for every meter type, so you can
-- see how far each one is from the 40-hour cut-off. The second block repeats it after
-- removing the suspect outlier tickets.
-- -------------------------------------------------------------------------------------
SELECT
    meter_type,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END), 1) AS avg_hours_with_visit,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END), 1) AS avg_hours_without_visit,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END)
        - AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END), 1) AS visit_uplift_hours
FROM utility_customer_operations
GROUP BY meter_type
ORDER BY visit_uplift_hours DESC;

SELECT
    meter_type,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END), 1) AS avg_hours_with_visit,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END), 1) AS avg_hours_without_visit,
    ROUND(AVG(CASE WHEN engineer_visit_required = 'Yes' THEN resolution_time_hours END)
        - AVG(CASE WHEN engineer_visit_required = 'No'  THEN resolution_time_hours END), 1) AS visit_uplift_hours
FROM utility_customer_operations
WHERE resolution_outlier_flag = 0
GROUP BY meter_type
ORDER BY visit_uplift_hours DESC;
