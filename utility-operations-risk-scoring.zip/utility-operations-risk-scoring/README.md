# Intelligent Utility Operations Risk Scoring & SLA Breach Prediction

**UK multi-utility (electricity, gas, water) customer operations - a Python → SQL → Power BI data-analyst portfolio project.**

A messy 100,000-row customer-service extract is cleaned by an automated Python pipeline, impossible records are
quarantined, the unreliable priority label is rebuilt from first principles, two risk features are engineered, and the
result is loaded into a SQL table that is analysed with four correlated-subquery / conditional-aggregation queries
and visualised in a Power BI command centre.

| | |
|---|---|
| **Stack** | Python (pandas, NumPy, SQLAlchemy, matplotlib) · SQL (MySQL 8 / MariaDB; SQLite fallback) · Power BI (Power Query, DAX) |
| **Input** | `data/raw/utility_operations_uk_dataset.csv` - 100,000 rows × 27 columns, deliberately unclean |
| **Output** | 94,796 validated rows in table `utility_customer_operations` · 4,504 quarantined rows · 4 SQL queries · Power BI build kit |

---

## 1. Quick start (Windows PowerShell)

```powershell
cd utility-operations-risk-scoring
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

python python/run_pipeline.py        # runs steps 1-6 (about 10 seconds)
python python/run_sql_queries.py     # runs the 4 SQL files and saves results to sql/results/
```

By default the table is created in a local SQLite file (nothing to install; note Query 2 takes ~40 s on SQLite versus a fraction of a second on MySQL). To load into **MySQL** instead
(then run the `.sql` files in MySQL Workbench):

```powershell
# in MySQL Workbench first:  CREATE DATABASE portfolio;
$env:DB_URL = "mysql+pymysql://USER:PASSWORD@localhost:3306/portfolio"
python python/run_pipeline.py
```

## 2. Repository map

```
├── README.md
├── requirements.txt
├── quarantined_utility_data.csv      <- 4,504 rejected rows, original text + reason (audit file)
├── data/
│   ├── raw/                          <- the supplied dataset (unchanged)
│   └── processed/utility_operations_clean.csv   <- cleaned + enriched table (Power BI source)
├── python/
│   ├── config.py                     <- all settings & thresholds in one place
│   ├── step1_ingest.py               <- ingestion, standardisation, dates, numerics
│   ├── step2_anomaly_filter.py       <- "Intelligent Filter" -> quarantine
│   ├── step3_priority.py             <- priority-tier recalculation
│   ├── step4_features.py             <- Customer_Friction_Score, Region_Resolution_Volatility_Index
│   ├── step5_load_db.py              <- SQL load + indexes
│   ├── step6_findings.py             <- companion charts + numbers for the README / Power BI check
│   ├── run_pipeline.py               <- runs everything
│   └── run_sql_queries.py            <- executes sql/query_*.sql
├── sql/
│   ├── query_1_silent_sla_breach.sql
│   ├── query_2_friction_spike_vulnerability.sql
│   ├── query_3_meter_type_engagement_stress_test.sql
│   ├── query_4_false_priority_alarm_audit.sql
│   └── results/                      <- CSV output of every query
├── powerbi/                          <- Power Query (M), DAX, theme, build guide, expected values
├── docs/
│   ├── data_quality_report.md        <- every cleaning decision, counted (auto-generated)
│   └── figures/                      <- Python companion charts
└── reports/headline_metrics.json
```

## 3. The pipeline, end to end

| Step | What happens | Key numbers |
|---|---|---|
| **1 Ingest & transform** | Read every column as text so nothing is silently altered; drop exact duplicate rows; standardise spelling/casing in 12 categorical columns (e.g. 23 region spellings → 12 regions); parse five date formats; strip `£` and thousand separators; null impossible values; flag every repair | 700 duplicates removed · 29,210 `£` values converted · 915 out-of-range CSAT scores nulled |
| **2 Intelligent Filter** | Quarantine mathematically impossible rows - negative consumption, resolution before request | **4,504** rows quarantined (947 negative consumption · 2,810 resolution-date before request · 2,497 negative resolution hours; 1,731 failed more than one rule) |
| **3 Priority recalculation** | Rebuild priority from outage minutes and resolution hours (rules below) | 62,418 of 94,796 legacy labels corrected |
| **4 Feature engineering** | `Customer_Friction_Score` and `Region_Resolution_Volatility_Index`, fully vectorised | Average friction score 89.0 |
| **5 Database load** | SQLAlchemy → `utility_customer_operations`, primary key + 6 indexes, row-count assertion | 94,796 rows |
| **6 Findings** | Python charts + numbers used below and to cross-check Power BI | |

### Priority recalculation logic (first matching rule wins)

| Order | Rule | Tier |
|---|---|---|
| 1 | `outage_related = Yes` **and** `outage_duration_minutes ≥ 180` | **Emergency** |
| 2 | `resolution_time_hours ≥ 120` | **High** |
| 3 | `resolution_time_hours ≥ 24` | **Medium** |
| 4 | anything else | **Low** |

Implemented with `numpy.select` (no row-wise loops). The legacy label is kept as `priority_raw`, and `priority_basis`
records which rule decided each row. **Caveat:** 13,443 tickets with no resolution time yet (still open) can only fall
through to *Low* - they are tagged `no_resolution_time_yet` so they can be filtered out.

### Engineered features

* **`Customer_Friction_Score`** - start at 100; −20 complaint; −15 outage-related; −10 CSAT ≤ 2; −10 resolution > SLA; clipped to 0-100.
* **`Region_Resolution_Volatility_Index`** - coefficient of variation `std ÷ mean × 100` of resolution hours per region (sample std). A second column, `..._Clean`, ignores suspect outliers: **≈ 583-633% with them vs ≈ 96-100% without.**

## 4. Data-cleaning decisions you should know about

Full counts are in [`docs/data_quality_report.md`](docs/data_quality_report.md).

| Issue | Decision | Why |
|---|---|---|
| Ambiguous slash dates (`05/06/2024` = 5 June or 6 May?) - 22,605 rows | Resolved using the *same row's* evidence: the gap between request and resolution must match `resolution_time_hours`; otherwise a plausible 0-15 day gap; then the extract's own date window (Jan 2023-Aug 2026); otherwise UK `DD/MM`. After parsing, 98.7% of rows have a date gap consistent with the logged hours | A blind `DD/MM` default would put ~100 requests in non-existent months and create false anomalies |
| Missing ≠ impossible | Blank readings/dates stay in the data; only *present but impossible* values are quarantined | A blank can't be tested |
| Resolution hours of 2,000-9,000 (1,480 rows; **1,417 remain after quarantine**) | **Kept, but flagged** (`resolution_outlier_flag`) | Normal tickets top out at ~360 h, and the ticket dates contradict these values - but deleting data without authority is worse than flagging. Every outlier-sensitive result is reported both ways |
| Negative billing (761) | Treated as sign errors → absolute value, flagged (`billing_sign_corrected_flag`). Switch to NULL in `config.py` | Negatives mirror the positive distribution |
| Blank `sla_target_hours` (3,918) | Filled from the standard SLA of the legacy tier (4/24/72/120 h), flagged (`sla_imputed_flag`) | The raw priority and SLA agree on ~94% of rows, so a few imputed values may be off |
| `complaint_flag` vs `complaint_category` conflicts (3,665) | The **flag is the source of truth** | The friction score is defined on the flag |
| Interaction IDs shared by different rows (588) | Kept and flagged; surrogate key `record_id` added | They are different interactions |

## 5. SQL analysis (no CTEs, no window functions)

Run on MariaDB 10.11 (MySQL-compatible). All results were cross-checked against an independent pandas calculation.

| Query | Technique | Result |
|---|---|---|
| **1 Silent SLA Breach** | multi-condition `HAVING` + nested `SUM(CASE…)` | **31** of 36 region × utility combinations; **0** after removing suspect outliers (second statement in the file) |
| **2 Friction Spike** | correlated subquery in `WHERE` | **3,160** one-star interactions billed above 1.5× their utility's average (peak 3.17×) |
| **3 Meter Type Stress Test** | cross-conditional aggregation | **0 rows** at the 40-hour threshold. Diagnostic: largest uplift is Prepayment meters at 24.5 h, and 0.3 h without outliers |
| **4 False Priority Alarm** | `COUNT()` + conditional `SUM()` | **London 21.0%**, **Yorkshire & Humber 20.8%** exceed 20% (legacy *Emergency* label resolved inside SLA) |

*Query 4 audits the legacy label (the thing a person raised). Variant B in the file audits the recalculated tier; there every region clears 20%, so the threshold stops discriminating.*

## 6. Headline findings

1. **The legacy priority label is noise.** Only **34.2%** of labels agree with the rule-based tier, and tickets average about **30-31 hours** to resolve whichever label they carry.
   ![priority](docs/figures/01_priority_legacy_vs_recalculated.png)
2. **The "silent SLA breach" is a data-quality artefact.** About **1.5%** of tickets (1,417) hold **76%** of all logged resolution hours and lift the average from **30.4 to 124.6 hours**. With them, 31 of 36 region × utility groups look like breaches; without them, none do.
   ![outliers](docs/figures/03_silent_breach_outlier_effect.png)
3. **SLA breaches depend on the target, not the place.** 89% of tickets with the 4-hour SLA breach versus 2% of those with the 120-hour SLA. Regions only range from **19.2% to 20.7%**.
   ![sla](docs/figures/04_breach_rate_by_sla_target.png)
4. **Engineer visits do not slow tickets down** (+0.1 h once outliers are excluded), and **billing level does not explain unhappiness**: 18.1% of one-star customers had a high bill versus 17.9% overall. CSAT is also 3.01 for complainants and non-complainants alike, so the survey may not be capturing service problems.
5. **Friction scores are flat across regions (88.7-89.3)** and driven by priority tier (Emergency 76 → Low 91). About **1 in 5** Emergency-labelled tickets is resolved inside SLA - London and Yorkshire & Humber are the highest.

## 7. Power BI

`powerbi/` contains everything for the single flat `Fact_Utility_Interactions` table (no star schema): Power Query script, DAX
(time-series KPIs, **smart-narrative text measure**, **multi-condition red/green KPI**, **what-if “Engineer Capacity Increase” 5-25%**),
a theme, a visual-by-visual build guide and expected values to validate your build. The `.pbix` must be saved from
Power BI Desktop - add it and your screenshots to `powerbi/` and `powerbi/screenshots/`.

## 8. Limitations

* Synthetic data: independent random fields (legacy priority vs hours, CSAT vs complaints) yield flat relationships - findings describe this dataset, not real operations.
* About 3,256 ambiguous request dates had nothing to cross-check and use the UK `DD/MM` reading (month may be wrong for some).
* Open tickets inflate the *Low* tier (see `priority_basis`).
* SLA imputation assumes the legacy label matches the SLA, which is true ~94% of the time.
