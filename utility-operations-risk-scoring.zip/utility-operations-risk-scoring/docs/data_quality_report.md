# Data-quality & pipeline run report

_Generated automatically by `run_pipeline.py` on 10 Nov 2026 14:33._

Every cleaning decision below is counted, so nothing happens silently.


## STEP 1 ingest

- raw rows read: 100,000
- raw columns: 27
- exact duplicate rows removed: 700
- account_number blank/invalid -> NULL: 2,871
- categorical columns standardised (utility, region, segment, meter, service, priority, payment, channel, Yes/No flags)
- postcode missing/malformed -> NULL: 6,571
- billing values that carried a '£' symbol: 29,210
- sla_target_hours blank -> filled from standard tier SLA: 3,918
- CSAT outside 1-5 scale -> NULL: 915
- negative billing amounts treated as sign errors (abs): 761
- negative outage duration -> NULL: 59
- resolution_time_hours > 1000h flagged as suspect outliers (kept): 1,480
- consumption > 500 units flagged as suspect outliers (kept): 734
- rows with an ambiguous DD/MM vs MM/DD date: 22,605
- data window inferred from unambiguous request dates: 2023-01-01 to 2026-08-31
- ambiguous dates resolved using resolution hours (tier 1): 18,932
- ambiguous dates resolved using plausible gap (tier 2): 417
-   of which only ONE reading fitted the evidence: 17,991
-   of which several readings fitted (data window, then UK DD/MM, preferred): 1,358
- ambiguous dates with no second date to check -> UK default DD/MM/YYYY: 3,256
- undecided ambiguous dates corrected using the data window: 72
- request_date invalid strings -> NULL: 1,014
- resolution_date invalid strings -> NULL: 464
- resolution_date blank (ticket still open): 13,934
- complaint flag = No but a category was present (category cleared): 1,554
- complaint flag = Yes but category blank (set to 'Not Recorded'): 2,111
- rows sharing an interaction_id with a different row (flagged, kept): 588
- rows leaving Step 1: 99,300

## STEP 2 anomaly filter

- rows failing NEGATIVE_CONSUMPTION: 947
- rows failing RESOLUTION_BEFORE_REQUEST: 2,810
- rows failing NEGATIVE_RESOLUTION_HOURS: 2,497
- rows failing more than one rule: 1,731
- rows quarantined: 4,504
- rows continuing to the main dataset: 94,796
- quarantine file written -> quarantined_utility_data.csv

## STEP 3 priority

- rows whose priority label was corrected: 62,418
- rows whose priority label already matched the rule: 32,378
- rows tiered 'Low' only because no resolution time exists yet: 13,443
- recalculated tier = Emergency: 1,570
- recalculated tier = High: 2,814
- recalculated tier = Medium: 34,417
- recalculated tier = Low: 55,995

## STEP 4 features

- average Customer_Friction_Score: 89.02
- region CV (with outliers)    min 582.8%  max 632.9%
- region CV (outliers removed) min 95.6%  max 100.3%
- SLA breach rate (known cases, %): 21.22

## STEP 5 database

- clean CSV written -> data/processed/utility_operations_clean.csv
- connecting to database (sqlite)
- rows loaded into utility_customer_operations: 94,796

## STEP 6 findings

- headline metrics saved -> reports/headline_metrics.json
- figure saved -> docs/figures/01_priority_legacy_vs_recalculated.png
- figure saved -> docs/figures/02_monthly_resolution_and_sla.png
- figure saved -> docs/figures/03_silent_breach_outlier_effect.png
- figure saved -> docs/figures/04_breach_rate_by_sla_target.png
- figure saved -> docs/figures/05_region_complaint_heatmap.png
- Power BI cross-check files saved -> powerbi/expected_values_*.{csv,json}
