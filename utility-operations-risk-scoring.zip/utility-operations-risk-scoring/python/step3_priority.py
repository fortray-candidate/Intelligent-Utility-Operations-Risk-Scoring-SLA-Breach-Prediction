"""
STEP 3 - Standardisation & Priority-tier recalculation
=======================================================
The raw `priority` column carries legacy call-centre indexing errors, so it is
rebuilt from what actually happened, using the project's severity rules
(first matching rule wins):

    1. outage_related = Yes  AND  outage_duration_minutes >= 180  ->  Emergency
    2. resolution_time_hours >= 120                               ->  High
    3. resolution_time_hours >= 24                                ->  Medium
    4. everything else                                            ->  Low

The old label is kept as `priority_raw` for auditing, and every row records
HOW its tier was decided (`priority_basis`) - important because a ticket with
no resolution time yet (still open) can only ever fall through to "Low".
"""
import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 3 priority"


def run(df):
    hours = df["resolution_time_hours"]
    emergency_rule = df["outage_related"].eq("Yes") & (df["outage_duration_minutes"] >= config.EMERGENCY_OUTAGE_MINUTES)

    # np.select evaluates the conditions in order - exactly the "first rule wins" logic above
    df["priority"] = np.select(
        [emergency_rule,
         hours >= config.HIGH_RESOLUTION_HOURS,
         hours >= config.MEDIUM_RESOLUTION_HOURS],
        ["Emergency", "High", "Medium"],
        default="Low",
    )
    df["priority_basis"] = np.select(
        [emergency_rule, hours.notna()],
        ["outage_rule", "resolution_time_rule"],
        default="no_resolution_time_yet",
    )
    df["priority_changed_flag"] = (df["priority"] != df["priority_raw"]).astype(int)

    log.metric(STEP, "rows whose priority label was corrected", int(df["priority_changed_flag"].sum()))
    log.metric(STEP, "rows whose priority label already matched the rule", int((1 - df["priority_changed_flag"]).sum()))
    log.metric(STEP, "rows tiered 'Low' only because no resolution time exists yet",
               int((df["priority_basis"] == "no_resolution_time_yet").sum()))
    for tier in ["Emergency", "High", "Medium", "Low"]:
        log.metric(STEP, f"recalculated tier = {tier}", int((df["priority"] == tier).sum()))
    return df
