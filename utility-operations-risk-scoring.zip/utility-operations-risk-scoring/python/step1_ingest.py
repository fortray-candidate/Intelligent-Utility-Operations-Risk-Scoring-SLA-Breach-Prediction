"""
STEP 1 - Robust data ingestion & transformation
================================================
Reads the raw CSV (every column as text, so nothing is silently changed) and:

  * removes exact duplicate rows
  * standardises spelling / casing variants in every categorical column
  * converts the five mixed date formats into real dates
    (including a cross-checking rule for ambiguous 05/06/2024-style dates)
  * enforces numeric types (strips the '£' symbol and thousand separators)
  * sets impossible values to NULL and records a flag for every repair

Nothing is *deleted* here except exact duplicate rows. The "mathematically
impossible" records are separated in Step 2.
"""
import re

import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 1 ingest"

# ----------------------------------------------------------------------------
# Canonical value lists:  {Clean label: [every spelling seen in the raw file]}
# Keys are compared in lower case with surrounding spaces removed.
# ----------------------------------------------------------------------------
UTILITY_MAP = {
    "Electricity": ["electricity", "elec", "electric", "electricty"],
    "Gas": ["gas", "gass", "natural gas"],
    "Water": ["water", "h2o", "water supply"],
}
REGION_MAP = {
    "East Midlands": ["east midlands", "e midlands"],
    "East of England": ["east of england"],
    "London": ["london", "greater london"],
    "North East": ["north east", "n.east"],
    "North West": ["north west", "n.west"],
    "Northern Ireland": ["northern ireland"],
    "Scotland": ["scotland"],
    "South East": ["south east", "s.east"],
    "South West": ["south west", "s.west"],
    "Wales": ["wales"],
    "West Midlands": ["west midlands", "w midlands"],
    "Yorkshire and the Humber": ["yorkshire and the humber", "yorkshire and humber",
                                 "yorkshire & humber", "yorks & humber", "yorkshire"],
}
SEGMENT_MAP = {
    "Domestic": ["domestic", "residential"],
    "Small Business": ["small business", "sme", "small biz"],
    "Commercial": ["commercial"],
    "Industrial": ["industrial"],
}
METER_MAP = {
    "Smart Meter": ["smart meter", "smart"],
    "Traditional Meter": ["traditional meter", "traditional", "standard meter", "dumb meter"],
    "Prepayment Meter": ["prepayment meter", "prepay", "payg meter"],
}
SERVICE_MAP = {
    "Billing Query": ["billing query", "billing issue"],
    "Complaint": ["complaint", "customer complaint"],
    "Disconnection": ["disconnection"],
    "Engineer Visit": ["engineer visit"],
    "Leak Report": ["leak report", "leak", "water leak"],
    "Meter Fault": ["meter fault"],
    "Meter Reading": ["meter reading"],
    "New Connection": ["new connection"],
    "Outage Report": ["outage report", "outage", "power cut", "supply outage"],
}
PRIORITY_MAP = {
    "Emergency": ["emergency", "urgent"],
    "High": ["high"],
    "Medium": ["medium", "med"],
    "Low": ["low"],
}
PAYMENT_MAP = {
    "Direct Debit": ["direct debit", "dd"],
    "Card": ["card", "credit card", "debit card"],
    "Cash": ["cash"],
    "Cheque": ["cheque"],
    "Standing Order": ["standing order"],
}
CHANNEL_MAP = {
    "Phone": ["phone", "telephone"],
    "Email": ["email"],
    "Web Chat": ["web chat", "webchat", "live chat"],
    "Mobile App": ["mobile app", "app"],
    "In Person": ["in person", "in-person", "branch"],
    "Post": ["post"],
}
COMPLAINT_CATEGORIES = ["Billing Dispute", "Incorrect Reading", "Missed Appointment",
                        "Overcharged", "Poor Service", "Staff Conduct", "Supply Interruption"]

YES_VALUES = {"y", "yes", "true", "1"}
NO_VALUES = {"n", "no", "false", "0"}


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def _invert(mapping):
    """{Clean: [variants]} -> {variant: Clean}"""
    return {variant: clean for clean, variants in mapping.items() for variant in variants}


def standardise(series, mapping, column):
    """Trim + lower-case the raw text and look it up in the mapping."""
    key = series.str.strip().str.lower()
    out = key.map(_invert(mapping))
    unmapped = int((out.isna() & key.ne("")).sum())
    if unmapped:
        log.info(STEP, f"WARNING {column}: {unmapped} values not in mapping -> NULL")
    return out


def blank_to_null(series):
    """Trim spaces; empty text becomes NULL."""
    s = series.str.strip()
    return s.where(s.ne(""))


def yes_no(series):
    key = series.str.strip().str.lower()
    out = pd.Series(np.where(key.isin(YES_VALUES), "Yes", np.where(key.isin(NO_VALUES), "No", None)),
                    index=series.index, dtype="object")
    return out


def to_number(series):
    """'£1,234.50' -> 1234.5 ; anything non-numeric -> NaN"""
    cleaned = (series.str.replace("£", "", regex=False)
                     .str.replace(",", "", regex=False)
                     .str.strip())
    return pd.to_numeric(cleaned, errors="coerce")


# ----------------------------------------------------------------------------
# dates
# ----------------------------------------------------------------------------
def _date_candidates(series):
    """
    Returns two Series (reading A, reading B) of real dates.

    * ISO (2024-12-31), 31-Dec-2024 and 31.12.2024 are unambiguous -> A == B.
    * 31/12/2024 style is ambiguous: A = read as DD/MM/YYYY, B = read as MM/DD/YYYY.
      An impossible reading (e.g. month 13) becomes NaT, so 13/05/2024 only has
      one valid reading and is resolved automatically.
    * Invalid strings (TBC, N/A, 00/00/0000, 31/02/2024 ...) are NaT in both.
    """
    s = series.str.strip()
    exact = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    for pattern, fmt in ((r"\d{4}-\d{2}-\d{2}", "%Y-%m-%d"),
                         (r"\d{2}-[A-Za-z]{3}-\d{4}", "%d-%b-%Y"),
                         (r"\d{2}\.\d{2}\.\d{4}", "%d.%m.%Y")):
        mask = s.str.fullmatch(pattern)
        if mask.any():
            parsed = pd.to_datetime(s[mask], format=fmt, errors="coerce").astype("datetime64[ns]")
            exact = exact.where(~mask, parsed.reindex(exact.index))

    parts = s.str.extract(r"^(\d{2})/(\d{2})/(\d{4})$").apply(pd.to_numeric)
    is_slash = parts[0].notna()
    dmy = pd.to_datetime({"year": parts[2], "month": parts[1], "day": parts[0]}, errors="coerce")
    mdy = pd.to_datetime({"year": parts[2], "month": parts[0], "day": parts[1]}, errors="coerce")
    dmy = dmy.astype("datetime64[ns]")
    mdy = mdy.astype("datetime64[ns]")

    a = exact.where(~is_slash, dmy)
    b = exact.where(~is_slash, mdy)
    return a, b


def parse_request_and_resolution(df):
    """
    Turns request_date / resolution_date into real dates.

    Ambiguous slash dates (both DD/MM and MM/DD are valid calendar dates) are
    resolved with evidence from the SAME ROW:

      Tier 1  - if resolution_time_hours is usable, pick the reading whose
                (resolution_date - request_date) gap in days equals
                floor(hours/24) or ceil(hours/24)   [verified on ~60k clean rows]
      Tier 2  - otherwise pick the reading that gives a plausible gap (0-15 days)
      Default - if there is no second date/hours to check against, use DD/MM/YYYY (UK convention),
                unless only the MM/DD reading falls inside the period the extract covers
                (when several readings fit the evidence, the one inside the period wins, then DD/MM)
    """
    req_a, req_b = _date_candidates(df["request_date_raw"])
    res_a, res_b = _date_candidates(df["resolution_date_raw"])

    # default reading: DD/MM first, fall back to the other reading if DD/MM is impossible
    req = req_a.fillna(req_b)
    res = res_a.fillna(res_b)

    amb_req = req_a.notna() & req_b.notna() & (req_a != req_b)
    amb_res = res_a.notna() & res_b.notna() & (res_a != res_b)
    ambiguous = amb_req | amb_res
    log.metric(STEP, "rows with an ambiguous DD/MM vs MM/DD date", int(ambiguous.sum()))

    # ---- snapshot window: where the extract starts and ends -----------------------------
    # The extract only covers a fixed period. Unambiguous request dates tell us where
    # that period starts and ends (months with stray spill-over rows are ignored).
    unambiguous_req = req_a.where(~amb_req)
    month_counts = unambiguous_req.dropna().dt.to_period("M").value_counts()
    solid_months = month_counts[month_counts >= 0.2 * month_counts.median()].index
    win_start, win_end = solid_months.min().start_time, solid_months.max().end_time
    log.info(STEP, f"data window inferred from unambiguous request dates: {win_start:%Y-%m-%d} to {win_end:%Y-%m-%d}")

    # candidates need both dates to exist in at least one reading
    testable = ambiguous & (req_a.notna() | req_b.notna()) & (res_a.notna() | res_b.notna())
    idx = df.index[testable]

    hours = df.loc[idx, "resolution_time_hours_numeric"]
    usable = hours.gt(0) & hours.lt(config.MAX_PLAUSIBLE_RESOLUTION_HOURS)
    lo = np.floor(hours / 24)
    hi = np.ceil(hours / 24)

    long_rows = []
    order = 0
    for rq_name, rq in (("A", req_a), ("B", req_b)):
        for rs_name, rs in (("A", res_a), ("B", res_b)):
            gap = (rs.loc[idx] - rq.loc[idx]).dt.days
            tier1 = usable & (gap == lo) | usable & (gap == hi)
            tier2 = (~usable) & gap.between(0, config.PLAUSIBLE_MAX_GAP_DAYS)
            long_rows.append(pd.DataFrame({"row": idx, "order": order,
                                           "rq": rq.loc[idx].values, "rs": rs.loc[idx].values,
                                           "ok": (tier1 | tier2).values, "tier1": usable.values}))
            order += 1
    long_df = pd.concat(long_rows, ignore_index=True)
    long_df = long_df[long_df["ok"] & long_df["rq"].notna() & long_df["rs"].notna()]
    long_df["outside_window"] = ~long_df["rq"].between(win_start, win_end)
    long_df = long_df.sort_values(["row", "outside_window", "order"])      # prefer readings inside the window, then DD/MM
    long_df = long_df.drop_duplicates(["row", "rq", "rs"])           # identical readings count once
    n_readings = long_df.groupby("row").size()
    # best consistent reading: inside the data window first, then DD/MM-first (UK convention)
    picked = long_df.drop_duplicates("row", keep="first").set_index("row")
    decisive = int((n_readings == 1).sum())
    tie_broken = int((n_readings > 1).sum())

    req.loc[picked.index] = picked["rq"]
    res.loc[picked.index] = picked["rs"]

    n_t1 = int(picked["tier1"].sum())
    log.metric(STEP, "ambiguous dates resolved using resolution hours (tier 1)", n_t1)
    log.metric(STEP, "ambiguous dates resolved using plausible gap (tier 2)", int(len(picked) - n_t1))
    log.metric(STEP, "  of which only ONE reading fitted the evidence", decisive)
    log.metric(STEP, "  of which several readings fitted (data window, then UK DD/MM, preferred)", tie_broken)
    log.metric(STEP, "ambiguous dates with no second date to check -> UK default DD/MM/YYYY", int(ambiguous.sum() - len(picked)))

    # ---- snapshot-window rule for undecided dates -------------------------------------
    # An ambiguous date with nothing to cross-check whose DD/MM reading falls OUTSIDE the
    # extract period, but whose MM/DD reading falls INSIDE it, is almost certainly the latter.
    undecided = amb_req & ~req.index.isin(picked.index)
    default_outside = (req_a < win_start) | (req_a > win_end)
    alt_inside = req_b.between(win_start, win_end)
    flip = undecided & default_outside & alt_inside
    req = req.where(~flip, req_b)
    log.metric(STEP, "undecided ambiguous dates corrected using the data window", int(flip.sum()))

    df["request_date"] = req
    df["resolution_date"] = res

    invalid_req = int((df["request_date_raw"].str.strip().ne("") & df["request_date"].isna()).sum())
    invalid_res = int((df["resolution_date_raw"].str.strip().ne("") & df["resolution_date"].isna()).sum())
    log.metric(STEP, "request_date invalid strings -> NULL", invalid_req)
    log.metric(STEP, "resolution_date invalid strings -> NULL", invalid_res)
    log.metric(STEP, "resolution_date blank (ticket still open)", int(df["resolution_date_raw"].str.strip().eq("").sum()))
    return df


# ----------------------------------------------------------------------------
# postcode
# ----------------------------------------------------------------------------
UK_POSTCODE = re.compile(r"^[A-Z]{1,2}\d[A-Z\d]?\d[A-Z]{2}$")


def clean_postcode(series):
    """Upper-case, squash spaces, validate, re-format as 'OUTWARD INWARD'."""
    squashed = series.str.upper().str.replace(r"\s+", "", regex=True)
    valid = squashed.str.fullmatch(UK_POSTCODE.pattern)
    formatted = squashed.str[:-3] + " " + squashed.str[-3:]
    return formatted.where(valid), valid


# ----------------------------------------------------------------------------
# main entry
# ----------------------------------------------------------------------------
def run():
    # 1. read everything as text -------------------------------------------------
    raw = pd.read_csv(config.RAW_CSV, dtype=str, keep_default_na=False)
    raw.insert(0, "source_row_number", np.arange(2, len(raw) + 2))   # line number in the CSV file
    log.metric(STEP, "raw rows read", len(raw))
    log.metric(STEP, "raw columns", raw.shape[1] - 1)

    # 2. exact duplicates -----------------------------------------------------------
    data_cols = [c for c in raw.columns if c != "source_row_number"]
    dupes = raw.duplicated(subset=data_cols, keep="first")
    log.metric(STEP, "exact duplicate rows removed", int(dupes.sum()))
    raw_kept = raw.loc[~dupes].copy()

    df = pd.DataFrame(index=raw_kept.index)
    df["source_row_number"] = raw_kept["source_row_number"]

    # 3. identifiers -----------------------------------------------------------------
    df["interaction_id"] = blank_to_null(raw_kept["interaction_id"])
    df["customer_id"] = blank_to_null(raw_kept["customer_id"])
    acct = raw_kept["account_number"].str.strip()
    df["account_number"] = acct.where(acct.str.fullmatch(r"\d{10}"))
    log.metric(STEP, "account_number blank/invalid -> NULL", int(df["account_number"].isna().sum()))

    # 4. categorical standardisation ----------------------------------------------
    df["utility_type"] = standardise(raw_kept["utility_type"], UTILITY_MAP, "utility_type")
    df["region"] = standardise(raw_kept["region"], REGION_MAP, "region")
    df["customer_segment"] = standardise(raw_kept["customer_segment"], SEGMENT_MAP, "customer_segment")
    df["meter_type"] = standardise(raw_kept["meter_type"], METER_MAP, "meter_type")
    df["service_type"] = standardise(raw_kept["service_type"], SERVICE_MAP, "service_type")
    df["priority_raw"] = standardise(raw_kept["priority"], PRIORITY_MAP, "priority")
    df["payment_method"] = standardise(raw_kept["payment_method"], PAYMENT_MAP, "payment_method")
    df["channel"] = standardise(raw_kept["channel"], CHANNEL_MAP, "channel")
    df["engineer_visit_required"] = yes_no(raw_kept["engineer_visit_required"])
    df["complaint_flag"] = yes_no(raw_kept["complaint_flag"])
    df["outage_related"] = yes_no(raw_kept["outage_related"])
    df["engineer_id"] = blank_to_null(raw_kept["engineer_id"])
    df["created_by_agent_id"] = blank_to_null(raw_kept["created_by_agent_id"])
    log.info(STEP, "categorical columns standardised (utility, region, segment, meter, service, "
                   "priority, payment, channel, Yes/No flags)")

    # 5. postcode -----------------------------------------------------------------------
    df["postcode"], pc_valid = clean_postcode(raw_kept["postcode"])
    log.metric(STEP, "postcode missing/malformed -> NULL", int(df["postcode"].isna().sum()))

    # 6. numerics -----------------------------------------------------------------------
    df["sla_target_hours"] = to_number(raw_kept["sla_target_hours"])
    df["resolution_time_hours"] = to_number(raw_kept["resolution_time_hours"])
    df["meter_reading_previous"] = to_number(raw_kept["meter_reading_previous"])
    df["meter_reading_current"] = to_number(raw_kept["meter_reading_current"])
    df["billing_amount_gbp"] = to_number(raw_kept["billing_amount_gbp"])
    df["customer_satisfaction_score"] = to_number(raw_kept["customer_satisfaction_score"])
    df["outage_duration_minutes"] = to_number(raw_kept["outage_duration_minutes"])
    log.metric(STEP, "billing values that carried a '£' symbol", int(raw_kept["billing_amount_gbp"].str.contains("£").sum()))

    # 6a. SLA target: fill blanks from the legacy priority (flagged) ---------------------
    sla_missing = df["sla_target_hours"].isna() & df["priority_raw"].notna()
    df.loc[sla_missing, "sla_target_hours"] = df.loc[sla_missing, "priority_raw"].map(config.SLA_BY_TIER)
    df["sla_imputed_flag"] = sla_missing.astype(int)
    log.metric(STEP, "sla_target_hours blank -> filled from standard tier SLA", int(sla_missing.sum()))

    # 6b. CSAT must be 1-5 -------------------------------------------------------------------
    bad_csat = df["customer_satisfaction_score"].notna() & ~df["customer_satisfaction_score"].between(config.CSAT_MIN, config.CSAT_MAX)
    df.loc[bad_csat, "customer_satisfaction_score"] = np.nan
    log.metric(STEP, "CSAT outside 1-5 scale -> NULL", int(bad_csat.sum()))

    # 6c. billing sign errors ---------------------------------------------------------------
    neg_bill = df["billing_amount_gbp"] < 0
    df["billing_sign_corrected_flag"] = neg_bill.astype(int)
    if config.NEGATIVE_BILLING_POLICY == "abs":
        df.loc[neg_bill, "billing_amount_gbp"] = df.loc[neg_bill, "billing_amount_gbp"].abs()
    else:
        df.loc[neg_bill, "billing_amount_gbp"] = np.nan
    log.metric(STEP, f"negative billing amounts treated as sign errors ({config.NEGATIVE_BILLING_POLICY})", int(neg_bill.sum()))

    # 6d. negative outage duration is impossible ---------------------------------------------
    bad_out = df["outage_duration_minutes"] < 0
    df.loc[bad_out, "outage_duration_minutes"] = np.nan
    log.metric(STEP, "negative outage duration -> NULL", int(bad_out.sum()))

    # 6e. suspect outliers: KEPT but flagged -------------------------------------------------
    df["resolution_outlier_flag"] = (df["resolution_time_hours"] > config.MAX_PLAUSIBLE_RESOLUTION_HOURS).astype(int)
    log.metric(STEP, f"resolution_time_hours > {config.MAX_PLAUSIBLE_RESOLUTION_HOURS}h flagged as suspect outliers (kept)",
               int(df["resolution_outlier_flag"].sum()))
    consumption = (df["meter_reading_current"] - df["meter_reading_previous"]).round(2)
    df["consumption_units"] = consumption
    df["consumption_outlier_flag"] = (consumption > config.MAX_PLAUSIBLE_CONSUMPTION_UNITS).astype(int)
    log.metric(STEP, f"consumption > {config.MAX_PLAUSIBLE_CONSUMPTION_UNITS} units flagged as suspect outliers (kept)",
               int(df["consumption_outlier_flag"].sum()))

    # 7. dates ------------------------------------------------------------------------------
    work = pd.DataFrame({
        "request_date_raw": raw_kept["request_date"],
        "resolution_date_raw": raw_kept["resolution_date"],
        "resolution_time_hours_numeric": df["resolution_time_hours"],
    })
    work = parse_request_and_resolution(work)
    df["request_date"] = work["request_date"]
    df["resolution_date"] = work["resolution_date"]
    df["request_month"] = df["request_date"].dt.to_period("M").dt.to_timestamp()

    # 8. complaint fields: the flag is the source of truth --------------------------------
    cat = standardise(raw_kept["complaint_category"], {c: [c.lower()] for c in COMPLAINT_CATEGORIES}, "complaint_category")
    flag_no_cat = df["complaint_flag"].eq("No") & cat.notna()
    flag_yes_nocat = df["complaint_flag"].eq("Yes") & cat.isna()
    df["complaint_conflict_flag"] = (flag_no_cat | flag_yes_nocat).astype(int)
    cat = cat.where(~flag_no_cat)                                   # flag says "not a complaint" -> drop category
    cat = cat.where(~flag_yes_nocat, "Not Recorded")                # flag says "complaint" but no category given
    df["complaint_category"] = cat
    log.metric(STEP, "complaint flag = No but a category was present (category cleared)", int(flag_no_cat.sum()))
    log.metric(STEP, "complaint flag = Yes but category blank (set to 'Not Recorded')", int(flag_yes_nocat.sum()))

    # 9. repeated interaction ids (different rows sharing one id) ---------------------------
    df["duplicate_interaction_id_flag"] = df["interaction_id"].duplicated(keep=False).astype(int)
    log.metric(STEP, "rows sharing an interaction_id with a different row (flagged, kept)",
               int(df["duplicate_interaction_id_flag"].sum()))

    # 9b. whole-number columns -> nullable integers (so the CSV shows 120, not 120.0)
    df["sla_target_hours"] = df["sla_target_hours"].round().astype("Int64")
    df["customer_satisfaction_score"] = df["customer_satisfaction_score"].round().astype("Int64")

    # 10. final column order (the 27 source columns first, then helpers) --------------------
    ordered = ["source_row_number", "interaction_id", "customer_id", "account_number", "utility_type", "region",
               "postcode", "customer_segment", "meter_type", "service_type", "priority_raw",
               "request_date", "resolution_date", "request_month", "sla_target_hours", "resolution_time_hours",
               "engineer_visit_required", "engineer_id", "meter_reading_previous", "meter_reading_current",
               "consumption_units", "billing_amount_gbp", "payment_method", "complaint_flag", "complaint_category",
               "customer_satisfaction_score", "channel", "outage_related", "outage_duration_minutes",
               "created_by_agent_id", "sla_imputed_flag", "billing_sign_corrected_flag", "resolution_outlier_flag",
               "consumption_outlier_flag", "complaint_conflict_flag", "duplicate_interaction_id_flag"]
    df = df[ordered].reset_index(drop=True)
    log.metric(STEP, "rows leaving Step 1", len(df))
    return df, raw
