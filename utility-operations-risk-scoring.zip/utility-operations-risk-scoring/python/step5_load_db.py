"""
STEP 5 - Database loading
==========================
Writes the validated, cleaned and enriched dataset into the SQL table
`utility_customer_operations` (SQLite by default, MySQL if DB_URL is set -
see config.py), adds a primary key + indexes, and proves the load by
counting the rows that landed.

It also saves the same data as a CSV (data/processed/...) which is the file
Power BI can load directly.
"""
import numpy as np
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy import Date, Float, Integer, String

import config
from pipeline_log import log

STEP = "STEP 5 database"

DATE_COLUMNS = ["request_date", "resolution_date", "request_month"]


def _column_types(df):
    """Explicit column types, so MySQL gets VARCHAR/DATE/DOUBLE instead of TEXT."""
    types = {}
    for col in df.columns:
        if col in DATE_COLUMNS:
            types[col] = Date()
        elif pd.api.types.is_float_dtype(df[col]):
            types[col] = Float(53)          # 53 = double precision (DOUBLE in MySQL)
        elif pd.api.types.is_integer_dtype(df[col]):
            types[col] = Integer()
        else:
            longest = int(df[col].astype(str).str.len().max())
            types[col] = String(max(10, longest + 5))
    return types


def run(df):
    df = df.copy()
    df.insert(0, "record_id", np.arange(1, len(df) + 1))          # surrogate primary key

    # tidy float noise & write the CSV used by Power BI
    config.CLEAN_CSV.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(config.CLEAN_CSV, index=False, date_format="%Y-%m-%d")
    log.info(STEP, f"clean CSV written -> {config.CLEAN_CSV.relative_to(config.PROJECT_ROOT)}")

    engine = create_engine(config.DB_URL)
    dialect = engine.dialect.name
    log.info(STEP, f"connecting to database ({dialect})")

    df.to_sql(config.TABLE_NAME, engine, if_exists="replace", index=False,
              dtype=_column_types(df), chunksize=5000)

    with engine.begin() as conn:
        if dialect == "mysql":
            conn.execute(text(f"ALTER TABLE {config.TABLE_NAME} ADD PRIMARY KEY (record_id)"))
        indexes = {
            "ix_uco_region_utility": "region, utility_type",
            "ix_uco_utility_billing": "utility_type, billing_amount_gbp",
            "ix_uco_meter_engineer": "meter_type, engineer_visit_required",
            "ix_uco_priority_raw": "priority_raw, region",
            "ix_uco_csat": "customer_satisfaction_score",
            "ix_uco_customer": "customer_id",
        }
        for name, cols in indexes.items():
            conn.execute(text(f"CREATE INDEX {name} ON {config.TABLE_NAME} ({cols})"))
        n_rows = conn.execute(text(f"SELECT COUNT(*) FROM {config.TABLE_NAME}")).scalar()

    log.metric(STEP, f"rows loaded into {config.TABLE_NAME}", int(n_rows))
    assert n_rows == len(df), "Row count in the database does not match the dataframe!"
    return df
