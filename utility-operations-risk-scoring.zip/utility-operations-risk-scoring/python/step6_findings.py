"""
STEP 6 - Companion charts & headline numbers (optional but handy)
==================================================================
Re-creates the key findings with Python so you can (a) paste numbers into the
README and (b) cross-check the Power BI dashboard against an independent
calculation. Charts are saved to docs/figures/ and numbers to
reports/headline_metrics.json.

NOTE: these are Python (matplotlib) charts - they are NOT Power BI screenshots.
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 6 findings"

NAVY, TEAL, ORANGE, RED, GREY = "#1F3A5F", "#2A9D8F", "#F4A261", "#E63946", "#8D99AE"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "figure.dpi": 130})


def _save(fig, name):
    config.FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(config.FIGURES_DIR / name, bbox_inches="tight")
    plt.close(fig)
    log.info(STEP, f"figure saved -> docs/figures/{name}")


def run(df):
    ok = df[df["resolution_outlier_flag"] == 0]
    m = {}

    # ---------------------------------------------------------------- headline numbers
    m["rows_in_main_table"] = int(len(df))
    m["priority_label_agreement_pct"] = round(float((1 - df["priority_changed_flag"].mean()) * 100), 1)
    m["avg_hours_by_legacy_priority"] = ok.groupby("priority_raw")["resolution_time_hours"].mean().round(1).to_dict()
    m["sla_breach_rate_pct_all"] = round(float(df["sla_breach_flag"].mean() * 100), 2)
    m["sla_breach_rate_pct_excl_outliers"] = round(float(ok["sla_breach_flag"].mean() * 100), 2)
    m["sla_breach_rate_by_sla_target_pct"] = {str(int(k)): v for k, v in
                                              (ok.groupby("sla_target_hours")["sla_breach_flag"].mean() * 100).round(1).items()}
    m["breach_rate_range_by_region_pct"] = [round(float(v * 100), 1) for v in
                                           (ok.groupby("region")["sla_breach_flag"].mean().min(),
                                            ok.groupby("region")["sla_breach_flag"].mean().max())]
    m["outlier_rows"] = int(df["resolution_outlier_flag"].sum())
    m["outlier_share_pct"] = round(float(df["resolution_outlier_flag"].mean() * 100), 2)
    m["avg_resolution_hours_incl_outliers"] = round(float(df["resolution_time_hours"].mean()), 1)
    m["avg_resolution_hours_excl_outliers"] = round(float(ok["resolution_time_hours"].mean()), 1)
    m["outlier_share_of_all_logged_hours_pct"] = round(float(
        df.loc[df["resolution_outlier_flag"] == 1, "resolution_time_hours"].sum() / df["resolution_time_hours"].sum() * 100), 1)
    m["avg_friction_score"] = round(float(df["Customer_Friction_Score"].mean()), 2)
    m["friction_by_priority"] = df.groupby("priority")["Customer_Friction_Score"].mean().round(1).to_dict()
    region_friction = df.groupby("region")["Customer_Friction_Score"].mean()
    m["friction_by_region_range"] = [round(float(region_friction.min()), 2), round(float(region_friction.max()), 2)]
    m["csat_by_complaint_flag"] = df.groupby("complaint_flag")["customer_satisfaction_score"].mean().round(2).to_dict()
    avg_bill = df.groupby("utility_type")["billing_amount_gbp"].transform("mean")
    high_bill = df["billing_amount_gbp"] > 1.5 * avg_bill
    m["high_bill_share_pct_all"] = round(float(high_bill.mean() * 100), 1)
    m["high_bill_share_pct_csat1"] = round(float(high_bill[df["customer_satisfaction_score"] == 1].mean() * 100), 1)
    m["engineer_visit_uplift_hours_excl_outliers"] = round(float(
        ok.loc[ok["engineer_visit_required"] == "Yes", "resolution_time_hours"].mean()
        - ok.loc[ok["engineer_visit_required"] == "No", "resolution_time_hours"].mean()), 2)
    m["recalculated_priority_mix_pct"] = (df["priority"].value_counts(normalize=True) * 100).round(1).to_dict()
    m["open_tickets_no_resolution_date"] = int(df["resolution_date"].isna().sum())

    config.REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    (config.REPORTS_DIR / "headline_metrics.json").write_text(json.dumps(m, indent=2, default=str))
    log.info(STEP, "headline metrics saved -> reports/headline_metrics.json")

    # ---------------------------------------------------------------- figure 1 : legacy vs recalculated priority
    order = ["Emergency", "High", "Medium", "Low"]
    cross = pd.crosstab(df["priority_raw"], df["priority"]).reindex(index=order, columns=order)
    share = cross.div(cross.sum(axis=1), axis=0) * 100
    fig, ax = plt.subplots(figsize=(7, 4))
    im = ax.imshow(share.values, cmap="Blues", vmin=0, vmax=100)
    ax.set_xticks(range(4)); ax.set_xticklabels(order)
    ax.set_yticks(range(4)); ax.set_yticklabels(order)
    ax.set_xlabel("Recalculated priority (rule-based)"); ax.set_ylabel("Legacy call-centre label")
    for i in range(4):
        for j in range(4):
            ax.text(j, i, f"{share.values[i, j]:.0f}%", ha="center", va="center",
                    color="white" if share.values[i, j] > 55 else "black")
    ax.set_title(f"Legacy labels carry no signal (only {m['priority_label_agreement_pct']:.0f}% agree with the rule)", fontsize=10)
    _save(fig, "01_priority_legacy_vs_recalculated.png")

    # ---------------------------------------------------------------- figure 2 : monthly trend
    monthly = (df.dropna(subset=["request_month"]).loc[lambda x: x["resolution_outlier_flag"] == 0]
                 .groupby("request_month")
                 .agg(avg_hours=("resolution_time_hours", "mean"), compliance=("sla_breach_flag", lambda s: (1 - s.mean()) * 100)))
    fig, ax1 = plt.subplots(figsize=(9, 3.8))
    ax1.plot(monthly.index, monthly["avg_hours"], color=NAVY, lw=2, label="Avg resolution hours")
    ax1.set_ylabel("Avg resolution hours", color=NAVY)
    ax2 = ax1.twinx()
    ax2.plot(monthly.index, monthly["compliance"], color=TEAL, lw=2, label="SLA compliance %")
    ax2.set_ylabel("SLA compliance %", color=TEAL)
    ax2.spines["right"].set_visible(True)
    ax1.set_title("Resolution time and SLA compliance by request month (suspect outliers excluded)")
    _save(fig, "02_monthly_resolution_and_sla.png")

    # ---------------------------------------------------------------- figure 3 : outlier distortion
    def pct_of_sla(frame):
        g = frame[frame["resolution_time_hours"].notna()].groupby(["region", "utility_type"])
        return g["resolution_time_hours"].mean() / g["sla_target_hours"].mean() * 100
    with_out, without = pct_of_sla(df), pct_of_sla(ok)
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.scatter(range(len(with_out)), with_out.sort_values().values, color=RED, label="All records")
    ax.scatter(range(len(without)), without.reindex(with_out.sort_values().index).values, color=TEAL, label="Suspect outliers removed")
    ax.axhline(150, color=GREY, ls="--"); ax.text(35, 138, "150% 'silent breach' threshold", color=GREY, fontsize=8, ha="right")
    ax.set_xlabel("36 region x utility combinations (sorted)"); ax.set_ylabel("Avg resolution as % of SLA")
    ax.set_title("The 'silent SLA breach' is created by 1.5% of records"); ax.legend(frameon=False)
    _save(fig, "03_silent_breach_outlier_effect.png")

    # ---------------------------------------------------------------- figure 4 : breach by SLA tier
    tier = (ok.groupby("sla_target_hours")["sla_breach_flag"].mean() * 100)
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.bar(range(len(tier)), tier.values, color=[RED, ORANGE, TEAL, NAVY])
    ax.set_xticks(range(len(tier)))
    ax.set_xticklabels([f"{int(h)}h SLA" for h in tier.index])
    for i, v in enumerate(tier.values):
        ax.text(i, v + 1.5, f"{v:.0f}%", ha="center")
    ax.set_ylabel("% of tickets breaching SLA"); ax.set_ylim(0, 100)
    ax.set_title("SLA breaches are about the target, not the place")
    _save(fig, "04_breach_rate_by_sla_target.png")

    # ---------------------------------------------------------------- figure 5 : region x complaint heatmap
    heat = pd.crosstab(df["region"], df.loc[df["complaint_category"].notna(), "complaint_category"])
    heat = heat.drop(columns=["Not Recorded"], errors="ignore")
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    im = ax.imshow(heat.values, cmap="OrRd", aspect="auto")
    ax.set_xticks(range(heat.shape[1])); ax.set_xticklabels(heat.columns, rotation=30, ha="right")
    ax.set_yticks(range(heat.shape[0])); ax.set_yticklabels(heat.index)
    for i in range(heat.shape[0]):
        for j in range(heat.shape[1]):
            ax.text(j, i, int(heat.values[i, j]), ha="center", va="center", fontsize=8)
    ax.set_title("Complaints by region and category (count)")
    fig.colorbar(im, ax=ax, shrink=0.8)
    _save(fig, "05_region_complaint_heatmap.png")

    return m


def export_powerbi_checks(df):
    """
    Writes powerbi/expected_values_by_region.csv - the numbers the Power BI measures
    SHOULD show when no slicer is selected and the outlier toggle is on
    "Exclude suspect outliers". Use it to prove the dashboard is calculating correctly.
    """
    ok = df[df["resolution_outlier_flag"] == 0]
    network_breach = ok["sla_breach_flag"].mean()
    network_friction = df["Customer_Friction_Score"].mean()
    network_hi_share = df["priority"].isin(["High", "Emergency"]).mean()

    rows = []
    for region, g in df.groupby("region"):
        g_ok = g[g["resolution_outlier_flag"] == 0]
        cats = g.loc[(g["complaint_flag"] == "Yes") & (g["complaint_category"] != "Not Recorded"), "complaint_category"].value_counts()
        top_cat = sorted(cats[cats == cats.max()].index)[-1]          # ties -> last alphabetically (same as DAX MAXX)
        breach = g_ok["sla_breach_flag"].mean()
        friction = g["Customer_Friction_Score"].mean()
        hi_share = g["priority"].isin(["High", "Emergency"]).mean()
        rows.append({
            "region": region,
            "total_interactions": len(g),
            "avg_resolution_hours_excl_outliers": round(g_ok["resolution_time_hours"].mean(), 2),
            "sla_compliance_pct": round((1 - breach) * 100, 2),
            "sla_breach_pct": round(breach * 100, 2),
            "avg_friction_score": round(friction, 2),
            "high_plus_emergency_share_pct": round(hi_share * 100, 2),
            "kpi_is_red": bool(friction < network_friction and hi_share > network_hi_share),
            "top_complaint_category": top_cat,
            "top_complaint_count": int(cats.max()),
        })
    out = pd.DataFrame(rows)
    path = config.PROJECT_ROOT / "powerbi" / "expected_values_by_region.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(path, index=False)

    hours = ok["resolution_time_hours"]
    summary = {
        "total_interactions": int(len(df)),
        "avg_resolution_hours_excl_outliers": round(float(hours.mean()), 2),
        "avg_resolution_hours_incl_outliers": round(float(df["resolution_time_hours"].mean()), 2),
        "sla_compliance_pct_excl_outliers": round(float((1 - network_breach) * 100), 2),
        "avg_friction_score_network": round(float(network_friction), 2),
        "high_plus_emergency_share_pct_network": round(float(network_hi_share * 100), 2),
        "total_resolution_hours_excl_outliers": round(float(hours.sum()), 1),
        "projected_hours_saved_at_10pct": round(float(hours.sum() * 0.10), 1),
        "projected_hours_saved_at_25pct": round(float(hours.sum() * 0.25), 1),
    }
    # projected SLA compliance at 10 % faster resolution (mirrors the DAX bonus measure)
    known = ok[ok["resolution_time_hours"].notna() & ok["sla_target_hours"].notna()]
    for pct in (0.05, 0.10, 0.25):
        summary[f"projected_sla_compliance_pct_at_{int(pct*100)}pct"] = round(
            float((known["resolution_time_hours"] * (1 - pct) <= known["sla_target_hours"]).mean() * 100), 2)
    (config.PROJECT_ROOT / "powerbi" / "expected_values_network.json").write_text(json.dumps(summary, indent=2))
    log.info(STEP, "Power BI cross-check files saved -> powerbi/expected_values_*.{csv,json}")
    return out, summary
