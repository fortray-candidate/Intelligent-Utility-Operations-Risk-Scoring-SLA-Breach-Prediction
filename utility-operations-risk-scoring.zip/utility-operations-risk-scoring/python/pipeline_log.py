"""Tiny logger that prints progress AND remembers every message, so the
data-quality report can be generated automatically at the end of the run."""
from datetime import datetime


class PipelineLog:
    def __init__(self):
        self.entries = []      # (step, message)
        self.metrics = {}      # step -> {name: value}

    def info(self, step, message):
        self.entries.append((step, message))
        print(f"[{datetime.now():%H:%M:%S}] {step:<22} {message}")

    def metric(self, step, name, value):
        self.metrics.setdefault(step, {})[name] = value
        shown = f"{value:,}" if isinstance(value, (int, float)) else value
        self.info(step, f"{name}: {shown}")


log = PipelineLog()
