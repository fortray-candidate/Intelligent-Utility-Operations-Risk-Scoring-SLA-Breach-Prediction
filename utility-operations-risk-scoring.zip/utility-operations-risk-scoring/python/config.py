"""
Central settings for the Utility Operations pipeline.
Change values here - nothing else in the code needs editing.
"""
import os
from pathlib import Path

# ---------------------------------------------------------------- paths
PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_CSV = PROJECT_ROOT / "data" / "raw" / "utility_operations_uk_dataset.csv"
CLEAN_CSV = PROJECT_ROOT / "data" / "processed" / "utility_operations_clean.csv"
QUARANTINE_CSV = PROJECT_ROOT / "quarantined_utility_data.csv"
REPORTS_DIR = PROJECT_ROOT / "reports"
FIGURES_DIR = PROJECT_ROOT / "docs" / "figures"
SQL_DIR = PROJECT_ROOT / "sql"
SQL_RESULTS_DIR = SQL_DIR / "results"

# ---------------------------------------------------------------- database
# Default = a local SQLite file (zero set-up, works on any laptop).
# To load into MySQL instead, set an environment variable BEFORE running:
#   PowerShell :  $env:DB_URL = "mysql+pymysql://USER:PASSWORD@localhost:3306/portfolio"
#   Mac/Linux  :  export DB_URL="mysql+pymysql://USER:PASSWORD@localhost:3306/portfolio"
# (create the empty database first:  CREATE DATABASE portfolio;)
DB_URL = os.getenv("DB_URL", f"sqlite:///{PROJECT_ROOT / 'data' / 'utility_operations.db'}")
TABLE_NAME = "utility_customer_operations"

# ---------------------------------------------------------------- business rules
# Priority recalculation (Phase 1, Step 3)
EMERGENCY_OUTAGE_MINUTES = 180
HIGH_RESOLUTION_HOURS = 120
MEDIUM_RESOLUTION_HOURS = 24

# Standard SLA turnaround (hours) for each priority tier - observed in the data
# (e.g. every correctly-labelled 'Emergency' ticket carries a 4h SLA).
SLA_BY_TIER = {"Emergency": 4, "High": 24, "Medium": 72, "Low": 120}

# ---------------------------------------------------------------- data-quality thresholds
# Normal resolution times top out at ~358h; the corrupt block starts at ~2,000h.
# Anything above this is flagged as a suspect outlier (kept, but flagged).
MAX_PLAUSIBLE_RESOLUTION_HOURS = 1000
# Normal consumption (current - previous reading) tops out at ~480 units; the
# corrupt block starts at ~525. Anything above is flagged (kept, but flagged).
MAX_PLAUSIBLE_CONSUMPTION_UNITS = 500
CSAT_MIN, CSAT_MAX = 1, 5

# Slash dates such as 05/06/2024 are ambiguous (5 June or 6 May?). When the
# logged resolution hours are unusable we accept a request->resolution gap
# between 0 and this many days as "plausible" evidence for the right reading.
PLAUSIBLE_MAX_GAP_DAYS = 15

# What to do with negative billing amounts: "abs" = treat as sign-entry error,
# "null" = blank them out. Either way they are flagged.
NEGATIVE_BILLING_POLICY = "abs"
