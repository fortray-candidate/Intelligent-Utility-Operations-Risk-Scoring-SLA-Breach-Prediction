"""
STEP 2 - Heuristic anomaly filtering  ("the Intelligent Filter")
=================================================================
Detects records that describe a mathematically impossible service scenario
and moves them OUT of the main dataset into quarantined_utility_data.csv.

  Rule 1  meter_reading_current < meter_reading_previous
          -> the customer would have used negative energy/water
  Rule 2  resolution_date earlier than request_date
          -> the ticket was "resolved" before it was logged
  Rule 3  resolution_time_hours < 0
          -> same impossibility, expressed as negative elapsed hours
             (kept as its own reason code so the audit trail is clear)

Missing values are NOT anomalies (a blank reading cannot be tested), so those
rows stay in the main dataset.

The quarantine file contains the ORIGINAL, untouched text of every rejected
row, plus the reason(s), so an auditor can trace it back to the source file.
"""
import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 2 anomaly filter"


def run(df, raw):
    reasons = pd.DataFrame(index=df.index)
    reasons["NEGATIVE_CONSUMPTION"] = (df["meter_reading_current"] < df["meter_reading_previous"]).fillna(False)
    reasons["RESOLUTION_BEFORE_REQUEST"] = (df["resolution_date"] < df["request_date"]).fillna(False)
    reasons["NEGATIVE_RESOLUTION_HOURS"] = (df["resolution_time_hours"] < 0).fillna(False)

    for name in reasons.columns:
        log.metric(STEP, f"rows failing {name}", int(reasons[name].sum()))

    is_bad = reasons.any(axis=1)
    both_dates_and_neg_hours = int((reasons["RESOLUTION_BEFORE_REQUEST"] & reasons["NEGATIVE_RESOLUTION_HOURS"]).sum())
    log.metric(STEP, "rows failing more than one rule", int((reasons.sum(axis=1) > 1).sum()))

    # ---- build the audit file from the ORIGINAL text values -------------------------
    bad_src = df.loc[is_bad, "source_row_number"]
    audit = raw[raw["source_row_number"].isin(bad_src)].copy()
    reason_text = reasons.loc[is_bad].apply(lambda r: "; ".join(r.index[r.values]), axis=1)
    reason_text.index = df.loc[is_bad, "source_row_number"].values
    audit["quarantine_reason"] = audit["source_row_number"].map(reason_text)
    audit["parsed_request_date"] = audit["source_row_number"].map(
        df.set_index("source_row_number")["request_date"].dt.strftime("%Y-%m-%d"))
    audit["parsed_resolution_date"] = audit["source_row_number"].map(
        df.set_index("source_row_number")["resolution_date"].dt.strftime("%Y-%m-%d"))
    audit["days_resolution_minus_request"] = audit["source_row_number"].map(
        (df["resolution_date"] - df["request_date"]).dt.days.set_axis(df["source_row_number"]))
    audit["consumption_units"] = audit["source_row_number"].map(df.set_index("source_row_number")["consumption_units"])
    audit = audit.sort_values("source_row_number")

    config.QUARANTINE_CSV.parent.mkdir(parents=True, exist_ok=True)
    audit.to_csv(config.QUARANTINE_CSV, index=False)

    clean = df.loc[~is_bad].reset_index(drop=True)
    log.metric(STEP, "rows quarantined", int(is_bad.sum()))
    log.metric(STEP, "rows continuing to the main dataset", len(clean))
    log.info(STEP, f"quarantine file written -> {config.QUARANTINE_CSV.name}")
    return clean, audit
