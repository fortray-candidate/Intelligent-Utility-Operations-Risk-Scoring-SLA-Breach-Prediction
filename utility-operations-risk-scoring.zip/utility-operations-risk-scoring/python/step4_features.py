"""
STEP 4 - Advanced programmatic analysis (feature engineering)
==============================================================
Both features are fully vectorised (no .apply() / lambda loops).

Analysis A  Customer_Friction_Score  (0-100, higher = smoother experience)
            start 100
            - 20  complaint_flag = Yes
            - 15  outage_related = Yes
            - 10  customer_satisfaction_score <= 2
            - 10  resolution_time_hours > sla_target_hours
            then clipped to the range 0-100

Analysis B  Region_Resolution_Volatility_Index
            Coefficient of Variation per region:  (std / mean) x 100
            of resolution_time_hours, mapped back onto every row.
            (sample standard deviation, ddof = 1, which is the pandas default)

            A second version, ..._Clean, ignores the rows flagged as suspect
            outliers (resolution_outlier_flag = 1). The headline index keeps them
            because the brief defines the index on resolution_time_hours as-is;
            the Clean version shows how much of the volatility is just bad data.
"""
import numpy as np
import pandas as pd

from pipeline_log import log

STEP = "STEP 4 features"


def run(df):
    hours = df["resolution_time_hours"]
    sla = df["sla_target_hours"]

    # ---- Analysis A ---------------------------------------------------------------------
    score = (100
             - 20 * df["complaint_flag"].eq("Yes")
             - 15 * df["outage_related"].eq("Yes")
             - 10 * (df["customer_satisfaction_score"] <= 2).fillna(False)   # unknown CSAT -> no penalty
             - 10 * (hours > sla).fillna(False))                              # unknown timing -> no penalty
    df["Customer_Friction_Score"] = np.clip(score.astype(int), 0, 100)
    log.metric(STEP, "average Customer_Friction_Score", round(float(df["Customer_Friction_Score"].mean()), 2))

    # ---- Analysis B ---------------------------------------------------------------------
    grp = df.groupby("region")["resolution_time_hours"]
    cv = (grp.std() / grp.mean() * 100).round(2)
    df["Region_Resolution_Volatility_Index"] = df["region"].map(cv)

    clean_grp = df.loc[df["resolution_outlier_flag"] == 0].groupby("region")["resolution_time_hours"]
    cv_clean = (clean_grp.std() / clean_grp.mean() * 100).round(2)
    df["Region_Resolution_Volatility_Index_Clean"] = df["region"].map(cv_clean)

    log.info(STEP, f"region CV (with outliers)    min {cv.min():.1f}%  max {cv.max():.1f}%")
    log.info(STEP, f"region CV (outliers removed) min {cv_clean.min():.1f}%  max {cv_clean.max():.1f}%")

    # ---- handy helper used by SQL / Power BI --------------------------------------------
    known = hours.notna() & sla.notna()
    df["sla_breach_flag"] = (hours > sla).astype("Int64").where(known)       # 1 = breached, 0 = met, NULL = unknown
    log.metric(STEP, "SLA breach rate (known cases, %)", round(float(df["sla_breach_flag"].mean() * 100), 2))
    return df
